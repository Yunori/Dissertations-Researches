DROP SEQUENCE theatre_seq;
DELETE FROM Theatre;
DROP SEQUENCE row_seq;
DELETE FROM Theatre_row;
DROP SEQUENCE seat_seq;
DELETE FROM Seat;
DROP SEQUENCE emp_seq;
DELETE FROM Employee;
DROP SEQUENCE movie_seq;
DELETE FROM movie;
DROP SEQUENCE t_type_seq;
DELETE FROM ticket_type;
commit;

CREATE SEQUENCE theatre_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE row_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seat_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

-- insert first theatre
INSERT INTO Theatre(theatre_id,theatre_description,theatre_total_rows) 
VALUES (theatre_seq.nextval,null,2);
-- insert first row in first theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'A', 3);
-- insert 3 seats of first row in first theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 3);

-- insert second row in first theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'B', 3);
-- insert 3 seats of second row in first theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 3);

-- insert second theatre
INSERT INTO Theatre(theatre_id,theatre_description,theatre_total_rows) 
VALUES (theatre_seq.nextval,null,2);
-- insert first row in second theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'A', 3);
-- insert 3 seats of first row in second theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 3);

-- insert second row in second theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'B', 4);
-- insert 4 seats of second row in second theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 3);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 4);

-- insert third theatre
INSERT INTO Theatre(theatre_id,theatre_description,theatre_total_rows) 
VALUES (theatre_seq.nextval,null,3);
-- insert first row in third theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'A', 3);
-- insert 3 seats of first row in third theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 3);

-- insert second row in third theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'B', 4);
-- insert 4 seats of second row in third theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 3);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 4);

-- insert third row in third theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'C', 5);
-- insert 5 seats of third row in third theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 3);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 4);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 5);

-- insert fourth theatre
INSERT INTO Theatre(theatre_id,theatre_description,theatre_total_rows) 
VALUES (theatre_seq.nextval,null,2);
-- insert first row in fourth theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'A', 3);
-- insert 3 seats of first row in fourth theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 3);

-- insert second row in fourth theatre
INSERT INTO Theatre_Row(row_id,theatre_id,row_name, row_total_seats) 
VALUES (row_seq.nextval,theatre_seq.currval, 'B', 3);
-- insert 3 seats of second row in fourth theatre
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES 
(seat_seq.nextval,row_seq.currval, 1);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 2);
INSERT INTO Seat(seat_id,row_id,seat_number) VALUES
(seat_seq.nextval,row_seq.currval, 3);

CREATE SEQUENCE emp_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
INSERT INTO Employee(e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) 
VALUES (emp_seq.nextval,'John','Smith','j.smith@uni.edu','07 3656 0877','12 Smith St','Dakota','4212','M',TO_DATE('12/01/2014','DD/MM/YYYY'));
INSERT INTO Employee(e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) 
VALUES (emp_seq.nextval,'Jane','Rooster','j.rooster@uni.edu','07 3656 0877','665 Angelside Mwy','Poolamatta','4246','F',TO_DATE('12/01/2014','DD/MM/YYYY'));
INSERT INTO Employee(e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) 
VALUES (emp_seq.nextval,'Percy Bisshe','Shelley','pb.shelley@uni.edu','07 3598 2154','3 Cigar Smoke Lane','Dakota','4623','F',TO_DATE('12/01/2014','DD/MM/YYYY'));
INSERT INTO Employee(e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) 
VALUES (emp_seq.nextval,'Mary','Shelley','m.shelley@uni.edu','07 3785 5764','17 Exam Way','Dakota','4214','F',TO_DATE('12/01/2014','DD/MM/YYYY'));

CREATE SEQUENCE movie_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
INSERT INTO Movie(movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) 
VALUES (movie_seq.nextval,'The Monuments Men','G',TO_DATE('10/01/2014','DD/MM/YYYY'),
        'An unlikely World War II platoon is tasked to rescue art masterpieces from Nazi thieves and return them to their owners.',118);
INSERT INTO Movie(movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) 
VALUES (movie_seq.nextval,'Non-Stop','MA15+',TO_DATE('20/04/2014','DD/MM/YYYY'),
        'An air marshal springs into action during a transatlantic flight after receiving a series of text messages that put his fellow passengers at risk unless the airline transfers $150 million into an off-shore account.',106);
INSERT INTO Movie(movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) 
VALUES (movie_seq.nextval,'Rise of an Empire','M',TO_DATE('12/01/2014','DD/MM/YYYY'),
        'Greek general Themistokles leads the charge against invading Persian forces led by mortal-turned-god Xerxes and Artemisia.',102);
INSERT INTO Movie(movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) 
VALUES (movie_seq.nextval,'Tracks','PG',TO_DATE('20/04/2014','DD/MM/YYYY'),
        'A young woman goes on a 1700 mile trek across the deserts of West Australia with her four camels and faithful dog.',118);

CREATE SEQUENCE t_type_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
INSERT INTO ticket_type(t_type_id,t_type,t_type_price,t_type_start_date,t_type_end_date) 
VALUES (t_type_seq.nextval,'Adult',10.95,TO_DATE('01/12/2015','DD/MM/YYYY'),TO_DATE('29/02/2016','DD/MM/YYYY'));
INSERT INTO ticket_type(t_type_id,t_type,t_type_price,t_type_start_date,t_type_end_date) 
VALUES (t_type_seq.nextval,'Concession',5.50,TO_DATE('01/12/2015','DD/MM/YYYY'),TO_DATE('29/02/2016','DD/MM/YYYY'));

COMMIT;


















