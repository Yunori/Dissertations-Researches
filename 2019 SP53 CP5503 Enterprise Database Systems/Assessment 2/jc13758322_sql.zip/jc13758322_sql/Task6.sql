DROP FUNCTION func_is_seat_available;

CREATE OR REPLACE FUNCTION func_is_seat_available (
    seat_id_p        IN   NUMBER,
    screening_id_p   IN   NUMBER
) RETURN NUMBER IS

    val            NUMBER;
    ticketrow   ticket%rowtype;
    -- GET the ticket with the same parameters, and set the cursor
    CURSOR c IS
    SELECT
        ticket.*
    FROM
        ticket
    WHERE
        seat_id_p = seat_id AND screening_id_p = screening_id;

BEGIN
    val := 0;
    OPEN c;
    FETCH c INTO ticketrow;
    -- Check if the previous SELECT statement found a ticket
    IF c%notfound THEN
        val := 1;
    END IF;
    CLOSE c;
    RETURN val;
END;

-- Inserting a ticket with seat_id = 1 & screening_id = 1
INSERT INTO ticket (ticket_id, ticket_date, seat_id, t_type_id, screening_id)
VALUES (1, TO_DATE('01/02/2016 19:45:00', 'dd/mm/yyyy hh24:mi:ss'), 1, 1, 15);

-- Testing the func_is_seat_available function with parameters that don't match any existing tickets
-- Expected result : Return 1
SELECT
    func_is_seat_available(666, 666)
FROM
    dual;

-- Testing the func_is_seat_available function with parameters that match an existing ticket
-- Expected result : Return 0
SELECT
    func_is_seat_available(1, 15)
FROM
    dual;