DROP TRIGGER TR_valid_15_minute_before_screening;

CREATE TRIGGER TR_valid_15_minute_before_screening BEFORE
    INSERT OR UPDATE OF ticket_date ON ticket
    FOR EACH ROW
DECLARE
    screening_date         screening.screening_date%TYPE;
    screening_start_hh24   screening.screening_start_hh24%TYPE;
    screening_start_mm60   screening.screening_start_mm60%TYPE;
BEGIN
    SELECT
        screening_date,
        screening_start_hh24,
        screening_start_mm60
    INTO
        screening_date,
        screening_start_hh24,
        screening_start_mm60
    FROM
        screening
    WHERE
        screening_id = :new.screening_id;

	-- Check that the ticket date+time is not more than 15 minutes higher than the screening time
    IF :new.ticket_date > screening_date + ( screening_start_hh24 ) / 24 + ( screening_start_mm60 + 15 ) / ( 24 * 60 ) THEN
        raise_application_error(-20066, 'The ticket issued date cannot be greater than screening time + 15 minutes.');
    END IF;

END;

DROP SEQUENCE ticket_seq;

CREATE SEQUENCE ticket_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

-- Testing the TR_valid_15_minute_before_screening trigger with an incorrect ticket_date value (+15min and 1 second).
-- Expected result : Error -20066: The ticket issued date cannot be greater than screening time + 15 minutes.
INSERT INTO ticket (ticket_id, ticket_date, seat_id, t_type_id, screening_id)
VALUES (ticket_seq.NEXTVAL, TO_DATE('01/02/2016 19:45:01', 'dd/mm/yyyy hh24:mi:ss'), 1, 1, 15);

-- Testing the TR_valid_15_minute_before_screening trigger with a correct ticket_date value.
-- Expected result : 1 row inserted
INSERT INTO ticket (ticket_id, ticket_date, seat_id, t_type_id, screening_id)
VALUES (ticket_seq.NEXTVAL, TO_DATE('01/02/2016 19:44:59', 'dd/mm/yyyy hh24:mi:ss'), 1, 1, 15);

-- NOTE: screening ID 15 date is 01/12/2016 19:30:00