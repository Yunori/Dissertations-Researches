DROP TABLE Ticket CASCADE CONSTRAINTS PURGE;
DROP TABLE Screening CASCADE CONSTRAINTS PURGE;
DROP TABLE Screening_Plan CASCADE CONSTRAINTS PURGE;
DROP TABLE Seat CASCADE CONSTRAINTS PURGE;
DROP TABLE theatre_row CASCADE CONSTRAINTS PURGE;
DROP TABLE Theatre CASCADE CONSTRAINTS PURGE;
DROP TABLE Ticket_Type CASCADE CONSTRAINTS PURGE;
DROP TABLE Movie CASCADE CONSTRAINTS PURGE;
DROP TABLE Employee CASCADE CONSTRAINTS PURGE;
COMMIT;

CREATE TABLE Employee
  (
    e_id          NUMBER (3) NOT NULL ,
    e_fname       VARCHAR2 (30) NOT NULL ,
    e_lname       VARCHAR2 (30) NOT NULL ,
    e_email       VARCHAR2 (50) NOT NULL ,
    e_phone       VARCHAR2 (20) NOT NULL ,
    e_street      VARCHAR2 (50) NOT NULL ,
    e_suburb      VARCHAR2 (30) NOT NULL ,
    e_postcode    VARCHAR2 (4) NOT NULL ,
    e_gender      VARCHAR2 (1) NOT NULL ,
    date_employed DATE NOT NULL
  ) ;
ALTER TABLE Employee ADD CONSTRAINT Employee_PK PRIMARY KEY ( e_id ) ;

CREATE TABLE Movie
  (
    movie_id            NUMBER (4) NOT NULL ,
    movie_title         VARCHAR2 (100) NOT NULL ,
    movie_rating        VARCHAR2 (10) NOT NULL ,
    movie_released_date DATE NOT NULL ,
    movie_description   VARCHAR2 (400) ,
    movie_length        NUMBER (3) NOT NULL
  ) ;
ALTER TABLE Movie ADD CONSTRAINT movie_PK PRIMARY KEY ( movie_id ) ;

CREATE TABLE Screening
  (
    screening_id         NUMBER (6) NOT NULL ,
    screening_date       DATE NOT NULL ,
    screening_start_hh24 NUMBER (2) NOT NULL ,
    screening_start_mm60 NUMBER (2) NOT NULL ,
    plan_id              NUMBER (4) NOT NULL ,
    theatre_id           NUMBER (1) NOT NULL
  ) ;
ALTER TABLE Screening ADD CONSTRAINT Screening_PK PRIMARY KEY ( screening_id ) ;

CREATE TABLE Screening_Plan
  (
    plan_id               NUMBER (4) NOT NULL ,
    plan_start_date       DATE NOT NULL ,
    plan_end_date         DATE NOT NULL ,
    plan_min_start_hh24   NUMBER (2) NOT NULL ,
    plan_max_start_hh24   NUMBER (2) NOT NULL ,
    plan_no_of_screenings NUMBER (2) NOT NULL ,
    movie_id              NUMBER (4) NOT NULL
  ) ;
ALTER TABLE Screening_Plan ADD CONSTRAINT Screening_Plan_PK PRIMARY KEY ( plan_id ) ;

CREATE TABLE Seat
  (
    seat_id     NUMBER (5) NOT NULL ,
    seat_number NUMBER (3) NOT NULL ,
    row_id      NUMBER (4) NOT NULL
  ) ;
ALTER TABLE Seat ADD CONSTRAINT seat_PK PRIMARY KEY ( seat_id ) ;

CREATE TABLE Theatre
  (
    theatre_id          NUMBER (1) NOT NULL ,
    theatre_description VARCHAR2 (100) ,
    theatre_total_rows  NUMBER (3) NOT NULL
  ) ;
ALTER TABLE Theatre ADD CONSTRAINT Theatre_PK PRIMARY KEY ( theatre_id ) ;

CREATE TABLE Ticket
  (
    ticket_id    NUMBER (8) NOT NULL ,
    ticket_date  DATE NOT NULL ,
    seat_id      NUMBER (5) NOT NULL ,
    t_type_id    NUMBER (2) NOT NULL ,
    screening_id NUMBER (6) NOT NULL
  ) ;
ALTER TABLE Ticket ADD CONSTRAINT Ticket_PK PRIMARY KEY ( ticket_id ) ;

CREATE TABLE Ticket_Type
  (
    t_type_id         NUMBER (2) NOT NULL ,
    t_type            VARCHAR2 (20) NOT NULL ,
    t_type_price      NUMBER (4,2) NOT NULL ,
    t_type_start_date DATE NOT NULL ,
    t_type_end_date   DATE
  ) ;
ALTER TABLE Ticket_Type ADD CONSTRAINT Ticket_Type_PK PRIMARY KEY ( t_type_id ) ;

CREATE TABLE theatre_row
  (
    row_id          NUMBER (4) NOT NULL ,
    row_name        VARCHAR2 (2) NOT NULL ,
    row_total_seats NUMBER (3) NOT NULL ,
    theatre_id      NUMBER (1) NOT NULL
  ) ;
ALTER TABLE theatre_row ADD CONSTRAINT theatre_row_PK PRIMARY KEY ( row_id ) ;

ALTER TABLE Screening_Plan ADD CONSTRAINT Screening_Plan_movie_FK FOREIGN KEY ( movie_id ) REFERENCES Movie ( movie_id ) ;
ALTER TABLE Screening ADD CONSTRAINT Screening_Screening_Plan_FK FOREIGN KEY ( plan_id ) REFERENCES Screening_Plan ( plan_id ) ;
ALTER TABLE Screening ADD CONSTRAINT Screening_Theatre_FK FOREIGN KEY ( theatre_id ) REFERENCES Theatre ( theatre_id ) ;
ALTER TABLE Ticket ADD CONSTRAINT Ticket_Screening_FK FOREIGN KEY ( screening_id ) REFERENCES Screening ( screening_id ) ;
ALTER TABLE Ticket ADD CONSTRAINT Ticket_Ticket_Type_FK FOREIGN KEY ( t_type_id ) REFERENCES Ticket_Type ( t_type_id ) ;
ALTER TABLE Ticket ADD CONSTRAINT Ticket_seat_FK FOREIGN KEY ( seat_id ) REFERENCES Seat ( seat_id ) ;
ALTER TABLE Seat ADD CONSTRAINT seat_theatre_row_FK FOREIGN KEY ( row_id ) REFERENCES theatre_row ( row_id ) ;
ALTER TABLE theatre_row ADD CONSTRAINT theatre_row_Theatre_FK FOREIGN KEY ( theatre_id ) REFERENCES Theatre ( theatre_id ) ;

COMMIT;
