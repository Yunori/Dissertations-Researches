BEGIN
	-- create screenings for day number 2 to 28
    FOR dayno IN 2..28 LOOP
		-- copy screening 1 to 19
        FOR scid IN 1..19 LOOP
            INSERT INTO screening (
                screening_id,
                screening_date,
                screening_start_hh24,
                screening_start_mm60,
                plan_id,
                theatre_id
            )
                SELECT
                    screening_id + 19 + dayno - 1,
                    screening_date + dayno - 1,
                    screening_start_hh24,
                    screening_start_mm60,
                    plan_id,
                    theatre_id
                FROM
                    screening
                WHERE
                    screening_id = scid;

        END LOOP;
    END LOOP;
END;