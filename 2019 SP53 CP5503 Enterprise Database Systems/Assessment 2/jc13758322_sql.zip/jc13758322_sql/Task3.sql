DROP SEQUENCE screening_plan_seq;
CREATE SEQUENCE screening_plan_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

INSERT INTO screening_plan (plan_id, plan_start_date, plan_end_date, plan_min_start_hh24, plan_max_start_hh24, plan_no_of_screenings, movie_id)
VALUES (screening_plan_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), TO_DATE('28/02/2016', 'dd/mm/yyyy'), 9, 17, 4, 1);

INSERT INTO screening_plan (plan_id, plan_start_date, plan_end_date, plan_min_start_hh24, plan_max_start_hh24, plan_no_of_screenings, movie_id)
VALUES (screening_plan_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), TO_DATE('28/02/2016', 'dd/mm/yyyy'), 9, 22, 6, 2);

INSERT INTO screening_plan (plan_id, plan_start_date, plan_end_date, plan_min_start_hh24, plan_max_start_hh24, plan_no_of_screenings, movie_id)
VALUES (screening_plan_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), TO_DATE('28/02/2016', 'dd/mm/yyyy'), 9, 22, 5, 3);

INSERT INTO screening_plan (plan_id, plan_start_date, plan_end_date, plan_min_start_hh24, plan_max_start_hh24, plan_no_of_screenings, movie_id)
VALUES (screening_plan_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), TO_DATE('28/02/2016', 'dd/mm/yyyy'), 9, 17, 4, 4);

DROP SEQUENCE screening_seq;
CREATE SEQUENCE screening_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 9, 30, 1, 4);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 12, 0, 1, 4);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 14, 30, 1, 4);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 17, 0, 1, 4);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 9, 30, 2, 3);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 12, 0, 2, 3);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 14, 30, 2, 3);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 17, 0, 2, 3);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 19, 30, 2, 3);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 19, 30, 2, 4);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 9, 30, 3, 1);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 12, 0, 3, 1);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 14, 30, 3, 1);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 17, 0, 3, 1);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 19, 30, 3, 1);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 9, 30, 4, 2);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 12, 0, 4, 2);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 14, 30, 4, 2);

INSERT INTO screening (screening_id, screening_date, screening_start_hh24, screening_start_mm60, plan_id, theatre_id)
VALUES (screening_seq.NEXTVAL, TO_DATE('01/02/2016', 'dd/mm/yyyy'), 17, 0, 4, 2);