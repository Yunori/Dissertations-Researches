DROP TRIGGER TR_change_gender_upper;

CREATE TRIGGER TR_change_gender_upper BEFORE
    INSERT OR UPDATE OF e_gender ON employee
    FOR EACH ROW
BEGIN
	-- Force the e_gender value to uppercase.
    :new.e_gender := upper(:new.e_gender);
END;

-- Testing the TR_change_gender_upper trigger with an lowercase e_gender value.
-- Expected result : (e_gender) 'm' -> (e_gender) 'M'
INSERT INTO employee (e_id, e_fname, e_lname, e_email, e_phone, e_street, e_suburb, e_postcode, e_gender, date_employed)
VALUES (emp_seq.NEXTVAL, 'kek', 'kek', 'kek@kek.kek', '6666666666', 'kekekekekekekek', 'kek', '6666', 'm', TO_DATE('11/11/2011', 'dd/mm/yyyy'));

SELECT
    *
FROM
    employee;