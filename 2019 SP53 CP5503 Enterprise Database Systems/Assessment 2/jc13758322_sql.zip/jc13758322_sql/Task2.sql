DROP TRIGGER TR_check_t_type;

CREATE TRIGGER TR_check_t_type BEFORE
    INSERT OR UPDATE OF t_type ON ticket_type
    FOR EACH ROW
BEGIN
	-- Check the t_type value
    IF :new.t_type NOT IN (
        'Adult',
        'Concession',
        'Student'
    ) THEN
        raise_application_error(-20666, 'Incorrect ticket type.');
    END IF;
END;

-- Testing the TR_check_t_type trigger with an incorrect t_type value.
-- Expected result : Error -20666: Incorrect ticket type.
INSERT INTO ticket_type (t_type_id, t_type, t_type_price, t_type_start_date, t_type_end_date)
VALUES (t_type_seq.NEXTVAL, 'Worker', 12.95, TO_DATE('1/12/2015', 'dd/mm/yyyy'), NULL);

-- Testing the TR_check_t_type trigger with a correct t_type value.
-- Expected result : 1 row inserted
INSERT INTO ticket_type (t_type_id, t_type, t_type_price, t_type_start_date, t_type_end_date)
VALUES (t_type_seq.NEXTVAL, 'Student', 7.95, TO_DATE('1/12/2015', 'dd/mm/yyyy'), NULL);

SELECT
    *
FROM
    ticket_type;