create or replace FUNCTION FUNC_GET_DATE_RETURNED(copy_id_p in number)
RETURN DATE is   
    date_returned_v date;
    cursor c1 is
      select date_returned   
      from loan
      where
        loan.copy_id = copy_id_p
      order by date_returned desc;        
BEGIN
  open c1;
  fetch c1 into date_returned_v;
  close c1;
  RETURN date_returned_v;
END;
