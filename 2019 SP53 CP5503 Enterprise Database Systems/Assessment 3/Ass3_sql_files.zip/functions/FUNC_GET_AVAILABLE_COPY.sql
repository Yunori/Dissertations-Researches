create or replace FUNCTION FUNC_GET_AVAILABLE_COPY
(
  copy_id_p in number
  
)
RETURN NUMBER AS 
  is_available_var NUMBER := 1;
  date_returned_var date;
  cursor c1 is
    select date_returned 
    from loan
    where
      loan.copy_id = copy_id_p
      order by date_returned desc;
BEGIN
  open c1;
  fetch c1 into date_returned_var;
  if c1%found and date_returned_var is null then 
      is_available_var := 0;
  end if;
  close c1;
  RETURN is_available_var;
  
END FUNC_GET_AVAILABLE_COPY;
