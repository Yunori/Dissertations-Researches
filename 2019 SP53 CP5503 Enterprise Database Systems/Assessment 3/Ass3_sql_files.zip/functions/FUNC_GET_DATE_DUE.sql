create or replace FUNCTION FUNC_GET_DATE_DUE(copy_id_p in number)
RETURN DATE is   
    date_due_v date;
    cursor c1 is
      select date_due   
      from loan
      where
        loan.copy_id = copy_id_p
      order by date_returned desc;        
BEGIN
  open c1;
  fetch c1 into date_due_v;
  close c1;
  RETURN date_due_v;
END;
