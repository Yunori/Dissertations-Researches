create or replace FUNCTION FUNC_COPY_AVAILABLE_STR
(
  copy_id_p in number 
)
RETURN VARCHAR2 is   
  available_str VARCHAR2(50) := ''; 
    
  
BEGIN
  if FUNC_GET_AVAILABLE_COPY(copy_id_p) = 1 then
    available_str := 'Yes';
  end if;
 
  RETURN available_str;
  
END;
