create or replace FUNCTION FUNC_GET_DATE_OUT(copy_id_p in number)
RETURN DATE is   
    date_out_v date;
    cursor c1 is
      select date_out   
      from loan
      where
        loan.copy_id = copy_id_p
      order by date_returned desc;        
BEGIN
  open c1;
  fetch c1 into date_out_v;
  close c1;
  RETURN date_out_v;
END;
