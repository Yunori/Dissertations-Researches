DROP SEQUENCE log_seq;
DELETE FROM log;
DROP SEQUENCE loan_seq;
DELETE FROM loan;
DROP SEQUENCE borrower_seq;
DELETE FROM borrower;
DROP SEQUENCE book_subject_seq;
DELETE FROM book_subject;
DROP SEQUENCE subject_seq;
DELETE FROM subject;
DROP SEQUENCE copy_seq;
DELETE FROM copies;
DROP SEQUENCE book_author_seq;
DELETE FROM book_author;
DROP SEQUENCE book_seq;
DELETE FROM book;
DROP SEQUENCE cat_seq;
DELETE FROM cat;
DROP SEQUENCE publisher_seq;
DELETE FROM publisher;
DROP SEQUENCE author_seq;
DELETE FROM author;
commit;

CREATE SEQUENCE cat_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

insert into cat(cat_id,cat_name) values (cat_seq.nextval,'BU');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'LA');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'AC');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'IT');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'TO');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'HO');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'HU');
insert into cat(cat_id,cat_name) values (cat_seq.nextval,'UN');

CREATE SEQUENCE author_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Donald','Kieso');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Jerry','Weygandt');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Terry','Warfield');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Ray','Garrison');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Eric','Noreen');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Peter','Brewer');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Carl','Warren');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'James','Reeve');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Jim','Collins');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Jerry','Porras');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'William','Lazier');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Luke','Welling');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Laura','Thompson');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Peter','Rob');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Carlos','Coronel');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Elie','Semaan');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Alan','Beaulieu');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Scott','Fitzgerald');
insert into author(author_id,author_fname,author_lname) values (author_seq.nextval,'Patricia','Smith');

CREATE SEQUENCE publisher_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'Wiley','http://www.wiley.com/','aus-custservice@wiley.com');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'McGraw-Hill','http://www.mcgraw-hill.com.au/','cservice_sydney@mcgraw-hill.com');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'South-Western College','http://www.cengage.com/us/','esales@cengage.com');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'HarperCollins','http://www.harpercollins.com.au/','feedback@harpercollins.com.au');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'Prentice Hall Press','http://www.prenticehall.com/','');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'MySQL Press','','');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'Course Technology','http://www.course.com','');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'O''Reilly Media','http://www.oreilly.com/','');
insert into publisher(publisher_id,publisher_name,publisher_url,publisher_email) values (publisher_seq.nextval,'Scribner','','');

-- turn off sqlplus interpreting &
set define off;

CREATE SEQUENCE book_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE copy_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0977326402',4,'Good to Great and the Social Sectors: A Monograph to Accompany Good to Great',1,'B',346,789,2,to_date('5/10/2005','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0060516406',4,'Built to Last: Successful Habits of Visionary Companies',1,'S',954,'',4,to_date('23/12/2001','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,4);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0133815269',5,'Beyond Entrepreneurship: Turning Your Business into an Enduring Great Company',1,'S',358,256,3,to_date('17/08/1997','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0743273565',9,'The Great Gatsby',8,'P',670,180,2,to_date('13/01/2009','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-1151736963',9,'The Beautiful and Damned',8,'P',683,240,1,to_date('13/01/2009','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0543722089',9,'Tender is the Night',8,'P',691,300,1,to_date('13/01/2009','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0470374948',1,'Intermediate Accounting',3,'I',352,1440,3,to_date('5/07/2010','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0073379616',2,'Managerial Accounting',3,'M',845,'',1,to_date('10/06/2010','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0324401882',3,'Financial & Managerial Accounting',3,'Z',671,512,2,to_date('7/12/2008','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0672325847',6,'MySQL Tutorial',4,'D',756,288,9,to_date('14/03/2003','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,4);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,5);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,6);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,7);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,8);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,9);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0672329166',6,'PHP and MySQL Web Development',4,'D',734,1008,7,to_date('14/03/2003','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,4);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,5);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,6);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,7);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-1423902010',7,'Database Systems: Design, Implementation, and Management',4,'D',465,704,6,to_date('14/03/2006','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,4);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,5);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,6);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0072886306',7,'Databases: Design Development & Deployment Using Microsoft Access',4,'D',725,552,4,to_date('14/03/2006','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,3);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,4);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0596007272',8,'Learning SQL',4,'W',335,289,2,to_date('16/05/2005','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-0684824482',9,'Babylon Revisited: And Other Stories',8,'P',699,272,1,to_date('13/01/2009','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);

insert into book(book_id,isbn,publisher_id,title,cat_id,shelf_letter,call_number,no_of_pages,no_of_copies,date_arrived) values
(book_seq.nextval,'978-1566892186',9,'Blood Dazzler',8,'Q',704,90,2,to_date('13/01/2009','DD/MM/YYYY'));
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,1);
insert into copies(copy_id,book_id,copy_number) values(copy_seq.nextval, book_seq.currval,2);

-- turn on sqlplus interpreting &
set define on;
set escape on;

CREATE SEQUENCE book_author_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,1,7);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,2,7);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,3,7);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,4,8);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,5,8);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,6,8);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,7,9);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,8,9);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,9,1);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,9,2);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,10,2);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,9,3);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,11,3);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,12,10);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,13,10);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,12,11);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,13,11);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,14,12);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,15,12);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,14,13);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,16,13);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,17,14);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,18,4);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,18,5);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,18,6);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,18,15);
insert into book_author(book_author_id,author_id,book_id) values(book_author_seq.nextval,19,16);

CREATE SEQUENCE subject_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
insert into subject(subject_id,subject_name,subject_code) values(subject_seq.nextval,'Enterpreneurship and Startups','BU477');
insert into subject(subject_id,subject_name,subject_code) values(subject_seq.nextval,'Accounting for IT Managers','AC365');
insert into subject(subject_id,subject_name,subject_code) values(subject_seq.nextval,'Web Development','WB507');
insert into subject(subject_id,subject_name,subject_code) values(subject_seq.nextval,'Introduction to Database Design','DB512');
insert into subject(subject_id,subject_name,subject_code) values(subject_seq.nextval,'Oracle Fundamentals','DB515');

CREATE SEQUENCE book_subject_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,3,1,'P');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,2,1,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,1,1,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,8,2,'P');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,9,2,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,11,3,'P');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,10,3,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,12,4,'P');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,10,4,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,13,4,'P');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,14,3,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,14,4,'R');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,14,5,'');
insert into book_subject(book_subject_id,book_id,subject_id,subject_ref) values(book_subject_seq.nextval,10,5,'');

CREATE SEQUENCE borrower_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
insert into borrower(borrower_id,borrower_fname,borrower_lname,borrower_email,borrower_phone,borrower_street,borrower_suburb,borrower_postcode,borrower_type,date_registered) 
values(borrower_seq.nextval,'John','Smith','j.smith@uni.edu','03 6656 0877','12 Smith St','Dakota','5212','S',to_date('12/01/2008','DD/MM/YYYY'));
insert into borrower(borrower_id,borrower_fname,borrower_lname,borrower_email,borrower_phone,borrower_street,borrower_suburb,borrower_postcode,borrower_type,date_registered)
 values(borrower_seq.nextval,'Vladimir','Lenin','v.lenin@uni.edu','09 4345 4435','65 Pine Ridge Ct','Mischief','3546','S',to_date('10/01/2008','DD/MM/YYYY'));
insert into borrower(borrower_id,borrower_fname,borrower_lname,borrower_email,borrower_phone,borrower_street,borrower_suburb,borrower_postcode,borrower_type,date_registered)
 values(borrower_seq.nextval,'Jane','Rooster','j.rooster@uni.edu','07 4345 4435','665 Angelside Mwy','Poolamatta','1246','S',to_date('12/01/2008','DD/MM/YYYY'));
insert into borrower(borrower_id,borrower_fname,borrower_lname,borrower_email,borrower_phone,borrower_street,borrower_suburb,borrower_postcode,borrower_type,date_registered)
 values(borrower_seq.nextval,'Percy Bisshe','Shelley','pb.shelley@uni.edu','03 6598 2154','3 Cigar Smoke Lane','Dakota','5623','S',to_date('12/01/2008','DD/MM/YYYY'));
insert into borrower(borrower_id,borrower_fname,borrower_lname,borrower_email,borrower_phone,borrower_street,borrower_suburb,borrower_postcode,borrower_type,date_registered)
 values(borrower_seq.nextval,'Mary','Shelley','m.shelley@uni.edu','03 9785 5764','17 Exam Way','Dakota','5214','L',to_date('12/01/2008','DD/MM/YYYY'));

CREATE SEQUENCE loan_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,2,22,to_date('18/10/2010','DD/MM/YYYY'),to_date('25/10/2010','DD/MM/YYYY'),to_date('20/10/2010','DD/MM/YYYY'));
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,3,27,to_date('17/11/2011','DD/MM/YYYY'),to_date('24/11/2011','DD/MM/YYYY'),to_date('20/11/2011','DD/MM/YYYY'));
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,4,30,to_date('20/11/2010','DD/MM/YYYY'),to_date('27/11/2010','DD/MM/YYYY'),to_date('22/11/2010','DD/MM/YYYY'));
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,5,49,to_date('21/11/2011','DD/MM/YYYY'),to_date('28/11/2011','DD/MM/YYYY'),to_date('25/11/2011','DD/MM/YYYY'));
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,1,13,to_date('21/11/2011','DD/MM/YYYY'),to_date('28/11/2011','DD/MM/YYYY'),to_date('30/11/2011','DD/MM/YYYY'));
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,2,22,to_date('7/08/2015','DD/MM/YYYY'),to_date('14/08/2015','DD/MM/YYYY'),'');
insert into loan(loan_id,borrower_id,copy_id,date_out,date_due,date_returned) values(loan_seq.nextval,5,14,to_date('7/08/2015','DD/MM/YYYY'),to_date('14/08/2015','DD/MM/YYYY'),'');

CREATE SEQUENCE log_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
commit;



















