DROP TABLE cat CASCADE CONSTRAINTS PURGE;
DROP TABLE author CASCADE CONSTRAINTS PURGE;
DROP TABLE book CASCADE CONSTRAINTS PURGE;
DROP TABLE book_author CASCADE CONSTRAINTS PURGE;
DROP TABLE book_subject CASCADE CONSTRAINTS PURGE;
DROP TABLE subject CASCADE CONSTRAINTS PURGE;
DROP TABLE copies CASCADE CONSTRAINTS PURGE;
DROP TABLE borrower CASCADE CONSTRAINTS PURGE;
DROP TABLE loan CASCADE CONSTRAINTS PURGE;
DROP TABLE log CASCADE CONSTRAINTS PURGE;
DROP TABLE publisher CASCADE CONSTRAINTS PURGE; 
commit;

CREATE TABLE Author
  (
    author_id    NUMBER (4) NOT NULL ,
    author_fname VARCHAR2 (50) NOT NULL ,
    author_lname VARCHAR2 (50) NOT NULL
  ) ;
ALTER TABLE Author ADD CONSTRAINT Author_PK PRIMARY KEY ( author_id ) ;

CREATE TABLE Book
  (
    book_id      NUMBER (6) NOT NULL ,
    isbn         VARCHAR2 (20) NOT NULL ,
    title        VARCHAR2 (100) NOT NULL ,
    shelf_letter VARCHAR2 (2) NOT NULL ,
    call_number  NUMBER (3) NOT NULL ,
    no_of_pages  NUMBER (4) ,
    no_of_copies NUMBER (3) NOT NULL ,
    date_arrived DATE NOT NULL ,
    publisher_id NUMBER (4) NOT NULL ,
    cat_id       NUMBER (2) NOT NULL
  ) ;
ALTER TABLE Book ADD CONSTRAINT Book_PK PRIMARY KEY ( book_id ) ;

CREATE TABLE Book_Author
  (
    book_author_id NUMBER (4) NOT NULL ,
    author_id      NUMBER (4) NOT NULL ,
    book_id        NUMBER (6) NOT NULL
  ) ;
ALTER TABLE Book_Author ADD CONSTRAINT Book_Author_PK PRIMARY KEY ( book_author_id ) ;

CREATE TABLE Book_Subject
  (
    book_subject_id NUMBER (6) NOT NULL ,
    subject_ref     VARCHAR2 (1) ,
    subject_id      NUMBER (3) NOT NULL ,
    book_id         NUMBER (6) NOT NULL
  ) ;
ALTER TABLE Book_Subject ADD CONSTRAINT Book_Subject_PK PRIMARY KEY ( book_subject_id ) ;

CREATE TABLE Borrower
  (
    borrower_id       NUMBER (6) NOT NULL ,
    borrower_fname    VARCHAR2 (50) NOT NULL ,
    borrower_lname    VARCHAR2 (50) NOT NULL ,
    borrower_email    VARCHAR2 (50) NOT NULL ,
    borrower_phone    VARCHAR2 (20) NOT NULL ,
    borrower_street   VARCHAR2 (50) NOT NULL ,
    borrower_suburb   VARCHAR2 (50) NOT NULL ,
    borrower_postcode VARCHAR2 (4) NOT NULL ,
    borrower_type     VARCHAR2 (1) NOT NULL ,
    date_registered   DATE NOT NULL
  ) ;
ALTER TABLE Borrower ADD CONSTRAINT Borrower_PK PRIMARY KEY ( borrower_id ) ;

CREATE TABLE Cat
  (
    cat_id   NUMBER (2) NOT NULL ,
    cat_name VARCHAR2 (2) NOT NULL
  ) ;
ALTER TABLE Cat ADD CONSTRAINT Cat_PK PRIMARY KEY ( cat_id ) ;

CREATE TABLE Copies
  (
    copy_id     NUMBER (6) NOT NULL ,
    copy_number NUMBER (3) NOT NULL ,
    book_id     NUMBER (6) NOT NULL
  ) ;
ALTER TABLE Copies ADD CONSTRAINT Copies_PK PRIMARY KEY ( copy_id ) ;

CREATE TABLE Loan
  (
    loan_id       NUMBER (8) NOT NULL ,
    date_out      DATE NOT NULL ,
    date_due      DATE NOT NULL ,
    date_returned DATE ,
    borrower_id   NUMBER (6) NOT NULL ,
    copy_id       NUMBER (6) NOT NULL
  ) ;
ALTER TABLE Loan ADD CONSTRAINT Loan_PK PRIMARY KEY ( loan_id ) ;

CREATE TABLE Log
  (
    log_id           NUMBER (8) NOT NULL ,
    dml_type         VARCHAR2 (1) NOT NULL ,
    pk_value         NUMBER (6) NOT NULL ,
    old_value        VARCHAR2 (50) ,
    new_value        VARCHAR2 (50) ,
    username         VARCHAR2 (30) NOT NULL ,
    transaction_date DATE NOT NULL
  ) ;
ALTER TABLE Log ADD CONSTRAINT Log_PK PRIMARY KEY ( log_id ) ;

CREATE TABLE Publisher
  (
    publisher_id    NUMBER (4) NOT NULL ,
    publisher_name  VARCHAR2 (50) NOT NULL ,
    publisher_url   VARCHAR2 (50) ,
    publisher_email VARCHAR2 (50)
  ) ;
ALTER TABLE Publisher ADD CONSTRAINT Publisher_PK PRIMARY KEY ( publisher_id ) ;

CREATE TABLE Subject
  (
    subject_id   NUMBER (3) NOT NULL ,
    subject_name VARCHAR2 (50) NOT NULL ,
    subject_code VARCHAR2 (15) NOT NULL
  ) ;
ALTER TABLE Subject ADD CONSTRAINT Subject_PK PRIMARY KEY ( subject_id ) ;

ALTER TABLE Book_Author ADD CONSTRAINT Book_Author_Author_FK FOREIGN KEY ( author_id ) REFERENCES Author ( author_id ) ;
ALTER TABLE Book_Author ADD CONSTRAINT Book_Author_Book_FK FOREIGN KEY ( book_id ) REFERENCES Book ( book_id ) ;
ALTER TABLE Book ADD CONSTRAINT Book_Cat_FK FOREIGN KEY ( cat_id ) REFERENCES Cat ( cat_id ) ;
ALTER TABLE Book ADD CONSTRAINT Book_Publisher_FK FOREIGN KEY ( publisher_id ) REFERENCES Publisher ( publisher_id ) ;
ALTER TABLE Book_Subject ADD CONSTRAINT Book_Subject_Book_FK FOREIGN KEY ( book_id ) REFERENCES Book ( book_id ) ;
ALTER TABLE Book_Subject ADD CONSTRAINT Book_Subject_Subject_FK FOREIGN KEY ( subject_id ) REFERENCES Subject ( subject_id ) ;
ALTER TABLE Copies ADD CONSTRAINT Copies_Book_FK FOREIGN KEY ( book_id ) REFERENCES Book ( book_id ) ;
ALTER TABLE Loan ADD CONSTRAINT Loan_Borrower_FK FOREIGN KEY ( borrower_id ) REFERENCES Borrower ( borrower_id ) ;
ALTER TABLE Loan ADD CONSTRAINT Loan_Copies_FK FOREIGN KEY ( copy_id ) REFERENCES Copies ( copy_id ) ;

commit;
