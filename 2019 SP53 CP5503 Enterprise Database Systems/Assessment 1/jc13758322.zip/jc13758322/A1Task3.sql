/* If need to drop first
DROP TABLE employee CASCADE CONSTRAINTS;
DROP TABLE movie CASCADE CONSTRAINTS;
DROP TABLE theatre CASCADE CONSTRAINTS;
DROP TABLE theatre_row CASCADE CONSTRAINTS;
DROP TABLE seat CASCADE CONSTRAINTS;
DROP TABLE screening_plan CASCADE CONSTRAINTS;
DROP TABLE screening CASCADE CONSTRAINTS;
DROP TABLE ticket CASCADE CONSTRAINTS;
DROP TABLE ticket_type CASCADE CONSTRAINTS;
*/

ALTER SESSION SET nls_date_format='yyyy-mm-dd hh24:mi:ss';

CREATE TABLE employee (
    e_id            NUMBER(3) NOT NULL,
    e_fname         VARCHAR2(30) NOT NULL,
    e_lname         VARCHAR2(30) NOT NULL,
    e_email         VARCHAR2(50) NOT NULL,
    e_phone         VARCHAR2(20) NOT NULL,
    e_street        VARCHAR2(50) NOT NULL,
    e_suburb        VARCHAR2(30) NOT NULL,
    e_postcode      VARCHAR2(4) NOT NULL,
    e_gender        VARCHAR2(1) NOT NULL,
    date_employed   DATE DEFAULT SYSDATE NOT NULL,
	CONSTRAINT check_e_id
    CHECK (e_id >= 0),
    CONSTRAINT check_e_email_synthax
    CHECK (REGEXP_LIKE (e_email,'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$')),
	CONSTRAINT check_e_email_unique
    UNIQUE(e_email),
	CONSTRAINT check_e_postcode
	CHECK (REGEXP_LIKE(e_postcode,'^(0[2-9]{1}[0-9]{2})$|^([1-9]{1}[0-9]{3})$')),
	CONSTRAINT check_e_gender
	CHECK (e_gender in ('M','F')),
	CONSTRAINT check_e_fname_e_lname
	UNIQUE(e_fname, e_lname)
);

ALTER TABLE employee ADD CONSTRAINT employee_pk PRIMARY KEY ( e_id );

CREATE TABLE movie (
    movie_id              NUMBER(4) NOT NULL,
    movie_title           VARCHAR2(100) NOT NULL,
    movie_rating          VARCHAR2(10) NOT NULL,
    movie_released_date   DATE DEFAULT TRUNC(SYSDATE) NOT NULL,
    movie_description     VARCHAR2(400),
    movie_length          NUMBER(3) NOT NULL,
	CONSTRAINT check_movie_id
	CHECK (movie_id >= 0),
	CONSTRAINT check_movie_rating
	CHECK (movie_rating in ('G','PG','M','MA15+','R18+'))
);

ALTER TABLE movie ADD CONSTRAINT movie_pk PRIMARY KEY ( movie_id );

CREATE TABLE screening (
    screening_id           NUMBER(6) NOT NULL,
    screening_date         DATE DEFAULT TRUNC(SYSDATE) NOT NULL,
    screening_start_hh24   NUMBER(2) NOT NULL,
    screening_start_mm60   NUMBER(2) NOT NULL,
    theatre_id             NUMBER(1) NOT NULL,
    plan_id                NUMBER(4) NOT NULL,
	CONSTRAINT check_screening_id
	CHECK (screening_id >= 0),
	CONSTRAINT check_screening_start_hh24
	CHECK (screening_start_hh24 BETWEEN 9 and 22),
	CONSTRAINT check_screening_start_mm60
	CHECK (screening_start_mm60 BETWEEN 0 and 59),
	CONSTRAINT check_theatre_id_screening_date_screening_start_hh24_screening_start_mm60_unique
	UNIQUE(theatre_id, screening_date, screening_start_hh24,  screening_start_mm60)
);

ALTER TABLE screening ADD CONSTRAINT screening_pk PRIMARY KEY ( screening_id );

CREATE TABLE screening_plan (
    plan_id                 NUMBER(4) NOT NULL,
    plan_start_date         DATE DEFAULT NEXT_DAY(SYSDATE,'MON') NOT NULL,
    plan_end_date           DATE DEFAULT NEXT_DAY(SYSDATE,'MON') + 6 NOT NULL,
    plan_min_start_hh24     NUMBER(2) DEFAULT 9 NOT NULL,
    plan_max_start_hh24     NUMBER(2) DEFAULT 22 NOT NULL,
    plan_no_of_screenings   NUMBER(2) NOT NULL,
    movie_id                NUMBER(4) NOT NULL,
	CONSTRAINT check_plan_id
	CHECK (plan_id >= 0),
	CONSTRAINT check_plan_min_start_hh24
	CHECK (plan_min_start_hh24 BETWEEN 9 and 22),
	CONSTRAINT check_plan_max_start_hh24
	CHECK (plan_max_start_hh24 BETWEEN 9 and 22),
	CONSTRAINT check_plan_no_of_screenings
	CHECK (plan_no_of_screenings >= 1),
	CONSTRAINT check_movie_id_plan_start_date_unique
	UNIQUE(movie_id, plan_start_date)
);

ALTER TABLE screening_plan ADD CONSTRAINT screening_plan_pk PRIMARY KEY ( plan_id );

CREATE TABLE seat (
    seat_id       NUMBER(5) NOT NULL,
    seat_number   NUMBER(3) NOT NULL,
    row_id        NUMBER(4) NOT NULL,
	CONSTRAINT check_seat_id
	CHECK (seat_id >= 0),
	CONSTRAINT check_seat_number
	CHECK (seat_id >= 1),
	CONSTRAINT check_row_id_seat_number_unique
	UNIQUE(row_id, seat_number)
);

ALTER TABLE seat ADD CONSTRAINT seat_pk PRIMARY KEY ( seat_id );

CREATE TABLE theatre (
    theatre_id            NUMBER(1) NOT NULL,
    theatre_description   VARCHAR2(100),
    theatre_total_rows    NUMBER(3) NOT NULL,
	CONSTRAINT check_theatre_id
	CHECK (theatre_id BETWEEN 1 and 5),
	CONSTRAINT check_theatre_total_rows
	CHECK (theatre_total_rows BETWEEN 1 and 26)
);

ALTER TABLE theatre ADD CONSTRAINT theatre_pk PRIMARY KEY ( theatre_id );

CREATE TABLE theatre_row (
    row_id            NUMBER(4) NOT NULL,
    row_name          VARCHAR2(2) NOT NULL,
    row_total_seats   NUMBER(3) NOT NULL,
    theatre_id        NUMBER(1) NOT NULL,
	CONSTRAINT check_row_id
	CHECK (row_id >= 0),
	CONSTRAINT check_row_name_alpha
	CHECK (row_name NOT LIKE '%[^A-Z]%'),
	CONSTRAINT check_row_name_len
	CHECK (LENGTHB(row_name) = 1),
	CONSTRAINT check_row_total_seats
	CHECK (row_total_seats >= 1),
	CONSTRAINT check_theatre_id_row_name_unique
	UNIQUE(theatre_id, row_name)
);

ALTER TABLE theatre_row ADD CONSTRAINT theatre_row_pk PRIMARY KEY ( row_id );

CREATE TABLE ticket (
    ticket_id      NUMBER(8) NOT NULL,
    ticket_date    DATE DEFAULT SYSDATE NOT NULL,
    screening_id   NUMBER(6) NOT NULL,
    t_type_id      NUMBER(1) NOT NULL,
    seat_id        NUMBER(5) NOT NULL,
    CONSTRAINT check_ticket_id
	CHECK (ticket_id >= 0),
	CONSTRAINT check_screening_id_seat_id
	UNIQUE(screening_id, seat_id)
);

ALTER TABLE ticket ADD CONSTRAINT ticket_pk PRIMARY KEY ( ticket_id );

CREATE TABLE ticket_type (
    t_type_id           NUMBER(1) NOT NULL,
    t_type              VARCHAR2(20) NOT NULL,
    t_type_price        NUMBER(4, 2) NOT NULL,
    t_type_start_date   DATE NOT NULL,
    t_type_end_date     DATE,
    CONSTRAINT check_t_type_id
	CHECK (t_type_id >= 0),
    CONSTRAINT check_t_type_price
	CHECK (t_type_id >= 0),
    CONSTRAINT check_t_type_end_date
	CHECK (t_type_end_date IS NULL OR t_type_end_date > t_type_start_date),
    CONSTRAINT check_t_type_t_type_start_date
	UNIQUE(t_type, t_type_start_date)
);

ALTER TABLE ticket_type ADD CONSTRAINT ticket_type_pk PRIMARY KEY ( t_type_id );

ALTER TABLE screening_plan
    ADD CONSTRAINT screening_plan_movie_fk FOREIGN KEY ( movie_id )
        REFERENCES movie ( movie_id );

ALTER TABLE screening
    ADD CONSTRAINT screening_screening_plan_fk FOREIGN KEY ( plan_id )
        REFERENCES screening_plan ( plan_id );

ALTER TABLE screening
    ADD CONSTRAINT screening_theatre_fk FOREIGN KEY ( theatre_id )
        REFERENCES theatre ( theatre_id );

ALTER TABLE seat
    ADD CONSTRAINT seat_theatre_row_fk FOREIGN KEY ( row_id )
        REFERENCES theatre_row ( row_id );

ALTER TABLE theatre_row
    ADD CONSTRAINT theatre_row_theatre_fk FOREIGN KEY ( theatre_id )
        REFERENCES theatre ( theatre_id );

ALTER TABLE ticket
    ADD CONSTRAINT ticket_screening_fk FOREIGN KEY ( screening_id )
        REFERENCES screening ( screening_id );

ALTER TABLE ticket
    ADD CONSTRAINT ticket_seat_fk FOREIGN KEY ( seat_id )
        REFERENCES seat ( seat_id );

ALTER TABLE ticket
    ADD CONSTRAINT ticket_ticket_type_fk FOREIGN KEY ( t_type_id )
        REFERENCES ticket_type ( t_type_id );
