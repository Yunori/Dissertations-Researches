/* If need to drop first
DROP SEQUENCE employee_seq;
DROP SEQUENCE movie_seq;
DROP SEQUENCE theatre_seq;
DROP SEQUENCE theatre_row_seq;
DROP SEQUENCE seat_seq;
DROP SEQUENCE ticket_type_seq;
*/

/* Sequences not used
 CREATE SEQUENCE ticket_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
 CREATE SEQUENCE screening_plan_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
 CREATE SEQUENCE ticket_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
*/

CREATE SEQUENCE employee_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE movie_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE theatre_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE theatre_row_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE seat_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE ticket_type_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

INSERT INTO employee (e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) VALUES (employee_seq.NEXTVAL,'John','Smith','j.smith@uni.edu','07 3656 0877','12 Smith St','Dakota','4212','M',TO_DATE('12/01/2014','dd/mm/yyyy'));
INSERT INTO employee (e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) VALUES (employee_seq.NEXTVAL,'Jane','Rooster','j.rooster@uni.edu','07 3656 0877','665 Angelside Mwy','Poolamatta','4246','F',TO_DATE('12/01/2014','dd/mm/yyyy'));
INSERT INTO employee (e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) VALUES (employee_seq.NEXTVAL,'Percy Bisshe','Shelley','pb.shelley@uni.edu','07 3598 2154','3 Cigar Smoke Lane','Dakota','4623','F',TO_DATE('12/01/2014','dd/mm/yyyy'));
INSERT INTO employee (e_id,e_fname,e_lname,e_email,e_phone,e_street,e_suburb,e_postcode,e_gender,date_employed) VALUES (employee_seq.NEXTVAL,'Mary','Shelley','m.shelley@uni.edu','07 3785 5764','17 Exam Way','Dakota','4214','F',TO_DATE('12/01/2014','dd/mm/yyyy'));

INSERT INTO movie (movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) VALUES (movie_seq.NEXTVAL,'The Monuments Men','G',TO_DATE('10/01/2014','dd/mm/yyyy'),'An unlikely World War II platoon is tasked to rescue art masterpieces from Nazi thieves and return them to their owners.',118);
INSERT INTO movie (movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) VALUES (movie_seq.NEXTVAL,'Non-Stop','MA15+',TO_DATE('20/04/2014','dd/mm/yyyy'),'An air marshal springs into action during a transatlantic flight after receiving a series of text messages that put his fellow passengers at risk unless the airline transfers $150 million into an off-shore account.',106);
INSERT INTO movie (movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) VALUES (movie_seq.NEXTVAL,'Rise of an Empire','M',TO_DATE('12/01/2014','dd/mm/yyyy'),'Greek general Themistokles leads the charge against invading Persian forces led by mortal-turned-god Xerxes and Artemisia.',102);
INSERT INTO movie (movie_id,movie_title,movie_rating,movie_released_date,movie_description,movie_length) VALUES (movie_seq.NEXTVAL,'Tracks','PG',TO_DATE('20/04/2014','dd/mm/yyyy'),'A young woman goes on a 1700 mile trek across the deserts of West Australia with her four camels and faithful dog.',118);

INSERT INTO theatre (theatre_id,theatre_total_rows) VALUES (theatre_seq.NEXTVAL,2);
INSERT INTO theatre (theatre_id,theatre_total_rows) VALUES (theatre_seq.NEXTVAL,2);
INSERT INTO theatre (theatre_id,theatre_total_rows) VALUES (theatre_seq.NEXTVAL,3);
INSERT INTO theatre (theatre_id,theatre_total_rows) VALUES (theatre_seq.NEXTVAL,2);

INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,1,'A',3);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,1,'B',3);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,2,'A',3);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,2,'B',4);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,3,'A',3);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,3,'B',4);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,3,'C',5);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,4,'A',3);
INSERT INTO theatre_row(row_id ,theatre_id,row_name,row_total_seats) VALUES(theatre_row_seq.NEXTVAL,4,'B',3);

INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,1,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,1,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,1,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,2,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,2,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,2,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,3,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,3,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,3,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,4,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,4,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,4,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,4,4);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,5,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,5,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,5,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,6,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,6,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,6,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,6,4);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,7,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,7,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,7,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,7,4);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,7,5);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,8,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,8,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,8,3);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,9,1);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,9,2);
INSERT INTO seat (seat_id,row_id,seat_number) VALUES (seat_seq.NEXTVAL,9,3);

INSERT INTO ticket_type(t_type_id,t_type,t_type_price,t_type_start_date,t_type_end_date ) VALUES (ticket_type_seq.NEXTVAL,'Adult',10.95,TO_DATE('01/12/2015','dd/mm/yyyy'),TO_DATE('29/02/2016','dd/mm/yyyy'));
INSERT INTO ticket_type(t_type_id,t_type,t_type_price,t_type_start_date,t_type_end_date ) VALUES (ticket_type_seq.NEXTVAL,'Concession',5.50,TO_DATE('01/12/2015','dd/mm/yyyy'),TO_DATE('29/02/2016','dd/mm/yyyy'));